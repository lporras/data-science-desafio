# cambiar por un for
#i = 0
#while i < 50:
#    print("Iteración {}".format(i+1))
#    i += 1
for i in range(50):
    print("Iteración {}".format(i+1))