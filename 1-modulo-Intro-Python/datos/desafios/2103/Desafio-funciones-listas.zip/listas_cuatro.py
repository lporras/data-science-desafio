from velocidad import promedio
from listas_uno import all_cars

for auto in all_cars:
  if auto[3] == True:
    print(auto[0])